<?php
session_start();
require_once "../../functions/functions.php";
require_once "../../db/connection/conn.php";
if(!isset($_SESSION['USER'])) {
    if (isset($_GET['email']) && isset($_GET['token'])) {
        $email = mysqli_real_escape_string($conn, $_GET['email']);
        $token = mysqli_real_escape_string($conn, $_GET['token']);

        $checkInfo = "SELECT userid FROM tbl_user WHERE email = '$email' AND token = '$token' AND token<>'' AND token_expire > NOW()";
        $checkInfoFire = mysqli_query($conn, $checkInfo);

        if (mysqli_num_rows($checkInfoFire) > 0) {
            $newPass = generateString();
            $encryptNewPass = sha1($newPass);

            $updatePassword = "UPDATE tbl_user SET token = '', password = '$encryptNewPass' WHERE email = '$email'";
            $updatePasswordFire = mysqli_query($conn, $updatePassword);

            if ($updatePasswordFire) {
                $_SESSION['NEW_PASSWORD'] = "Generated Password: <br/><b>" . $newPass . "</b><br/>Note it down now<br/>Please change your password after login";
                redirectSuccess();
            }
        } else {
            redirectFail();
            $_SESSION['NEW_PASSWORD_STATUS'] = "Link has been expired";
        }
    } else {
        redirectFail();
        $_SESSION['UNAUTHORIZED_ACCESS'] = "Link is manipulated, unauthorised error !!";
    }
}
else{
    header("location:http://localhost/Rendigitization/index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="../../styleassets/css/style.css">
    <link rel="stylesheet" href="../../styleassets/css/main.css">
</head>
<body>
    
</body>
</html>