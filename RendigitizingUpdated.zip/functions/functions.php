<?php
function generateString($len = 10)
{
    $token = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM1234567890";
    $token = str_shuffle($token);
    $token = substr($token, 0, $len);

    return $token;
}
function redirectSuccess()
{
    header("location:http://localhost/RenDigitizingUpdated/user/authentication/login.php?resetpassword=success");
    exit();
}
function redirectFail()
{
    header("location:http://localhost/RenDigitizingUpdated/user/authentication/login.php?resetpassword=fail");
    exit();
}